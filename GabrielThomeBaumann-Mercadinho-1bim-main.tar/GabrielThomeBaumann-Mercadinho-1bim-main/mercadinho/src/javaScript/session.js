
// --- Sessão automática ---
function logout() {
  localStorage.removeItem('usuarioLogado');
  localStorage.removeItem('userRole');
  localStorage.removeItem('userName');
  alert('Sessão encerrada por inatividade ou fechamento da página.');
  window.location.href = 'login.html';
}

// ⏱️ Inatividade por 5 minutos
let tempoLimite = 5 * 60 * 1000; // 5 minutos
let timeout;

function resetarTimer() {
  clearTimeout(timeout);
  timeout = setTimeout(logout, tempoLimite);
}

['click', 'mousemove', 'keydown', 'scroll', 'touchstart'].forEach(event => {
  document.addEventListener(event, resetarTimer, true);
});

resetarTimer(); // Inicia o timer ao carregar a página
