
document.addEventListener('DOMContentLoaded', async () => {
  const tbody = document.getElementById('usuarios-body');

  let usuarios = [];

  // 🔁 Buscar usuários do servidor
  async function carregarUsuarios() {
    const res = await fetch('http://localhost:3000/usuarios');
    usuarios = await res.json();
    renderUsuarios();
  }

  function renderUsuarios() {
    tbody.innerHTML = '';
    usuarios.forEach((usuario, index) => {
      const tr = document.createElement('tr');
      tr.innerHTML = `
        <td>${usuario.userName}</td>
        <td>${usuario.email}</td>
        <td>${usuario.age}</td>
        <td>${usuario.gender}</td>
        <td>${usuario.role.charAt(0).toUpperCase() + usuario.role.slice(1)}</td>
        <td>
          <button onclick="promoverUsuario(${index})">
            ${usuario.role === 'cliente' ? 'Promover a Gerente' : 'Rebaixar a Cliente'}
          </button>
          <button onclick="editarUsuario(${index})">Editar</button>
          <button onclick="removerUsuario(${index})" style="background-color:red;">Remover</button>
        </td>
      `;
      tbody.appendChild(tr);
    });
  }

  window.promoverUsuario = (index) => {
    usuarios[index].role = usuarios[index].role === 'cliente' ? 'gerente' : 'cliente';
    renderUsuarios();
    // Aqui você pode fazer um PUT para persistir no servidor
  };

  window.removerUsuario = (index) => {
    if (confirm(`Tem certeza que deseja remover ${usuarios[index].userName}?`)) {
      usuarios.splice(index, 1);
      renderUsuarios();
      // Aqui você pode fazer um DELETE no servidor
    }
  };

  window.editarUsuario = (index) => {
    const usuario = usuarios[index];
    const novoNome = prompt('Novo nome:', usuario.userName);
    const novoEmail = prompt('Novo e-mail:', usuario.email);
    const novaIdade = prompt('Nova idade:', usuario.age);
    const novoGenero = prompt('Novo gênero (Masculino/Feminino):', usuario.gender);

    if (novoNome && novoEmail && novaIdade && novoGenero) {
      usuarios[index] = {
        ...usuario,
        userName: novoNome,
        email: novoEmail,
        age: parseInt(novaIdade),
        gender: novoGenero,
        role: usuario.role
      };
      renderUsuarios();
      // Aqui você pode fazer um PUT para atualizar no servidor
    }
  };

  document.getElementById('atualizar').addEventListener('click', carregarUsuarios);

  await carregarUsuarios(); // Inicializa
});

window.addEventListener('beforeunload', () => {
  localStorage.removeItem('usuarioLogado');
  localStorage.removeItem('userRole');
  localStorage.removeItem('userName');
});
