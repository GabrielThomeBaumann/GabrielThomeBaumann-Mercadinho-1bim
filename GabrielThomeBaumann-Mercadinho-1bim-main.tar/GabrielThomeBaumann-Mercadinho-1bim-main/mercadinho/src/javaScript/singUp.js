async function cadastrarUsuario() {
  const userName = document.getElementById('userName').value;
  const email = document.getElementById('gmail').value;
  const age = parseInt(document.getElementById('age').value);
  const password = document.getElementById('password').value;
  const gender = document.getElementById('gender').value;

  const res = await fetch('http://localhost:3000/cadastro', {
    method: 'POST',
    headers: {'Content-Type': 'application/json'},
    body: JSON.stringify({ userName, email, age, password, gender })
  });

  const data = await res.json();

  if (data.success) {
    alert('Cadastro realizado com sucesso!');
    window.location.href = 'login.html';
  } else {
    alert(data.message);
  }
}

window.addEventListener('beforeunload', () => {
  localStorage.removeItem('usuarioLogado');
  localStorage.removeItem('userRole');
  localStorage.removeItem('userName');
});