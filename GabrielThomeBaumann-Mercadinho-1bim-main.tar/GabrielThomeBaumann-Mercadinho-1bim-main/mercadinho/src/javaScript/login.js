async function fazerLogin() {
  const userName = document.getElementById('userName').value;
  const password = document.getElementById('password').value;

  const res = await fetch('http://localhost:3000/login', {
    method: 'POST',
    headers: {'Content-Type': 'application/json'},
    body: JSON.stringify({ userName, password })
  });

  const data = await res.json();

  if (data.success) {
    localStorage.setItem('usuarioLogado', JSON.stringify({ userName }));
    localStorage.setItem('userRole', data.role);
    localStorage.setItem('userName', userName);

    if (data.role === 'gerente') {
      window.location.href = 'Admin(1).html';
    } else {
      window.location.href = 'index.html';
    }
  } else {
    alert('Usuário ou senha inválidos');
  }
}

window.addEventListener('beforeunload', () => {
  localStorage.removeItem('usuarioLogado');
  localStorage.removeItem('userRole');
  localStorage.removeItem('userName');
});