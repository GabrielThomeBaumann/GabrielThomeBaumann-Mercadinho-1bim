const express = require('express');
const cors = require('cors');
const fs = require('fs');
const path = require('path');

const app = express();
const PORT = 3000;

app.use(cors());
app.use(express.json());

// -------------------- Caminhos dos arquivos --------------------
const USERS_PATH = path.join(__dirname, 'usuarios.json');
const PRODUCTS_PATH = path.join(__dirname, 'produtos.json');

// -------------------- Usuários --------------------
if (!fs.existsSync(USERS_PATH)) {
  const defaultUsers = [
    {
      userName: "admin",
      email: "admin@mercado.com",
      age: 30,
      password: "admin123",
      gender: "male",
      role: "gerente"
    }
  ];
  fs.writeFileSync(USERS_PATH, JSON.stringify(defaultUsers, null, 2));
}

function readUsers() {
  return JSON.parse(fs.readFileSync(USERS_PATH, 'utf-8'));
}

function saveUsers(users) {
  fs.writeFileSync(USERS_PATH, JSON.stringify(users, null, 2));
}

app.get('/usuarios', (req, res) => {
  res.json(readUsers());
});

app.post('/login', (req, res) => {
  const { userName, password } = req.body;
  const users = readUsers();
  const user = users.find(u => u.userName === userName && u.password === password);
  if (user) {
    res.json({ success: true, role: user.role });
  } else {
    res.status(401).json({ success: false, message: 'Usuário ou senha inválido' });
  }
});

app.post('/cadastro', (req, res) => {
  const newUser = req.body;
  const users = readUsers();

  if (users.find(u => u.userName === newUser.userName)) {
    return res.status(400).json({ success: false, message: 'Usuário já existe' });
  }

  newUser.role = 'cliente';
  users.push(newUser);
  saveUsers(users);
  res.json({ success: true });
});

// -------------------- Produtos --------------------
function readProducts() {
  return JSON.parse(fs.readFileSync(PRODUCTS_PATH, 'utf-8'));
}

function saveProducts(products) {
  fs.writeFileSync(PRODUCTS_PATH, JSON.stringify(products, null, 2));
}

app.get('/produtos', (req, res) => {
  res.json(readProducts());
});

app.post('/produtos', (req, res) => {
  const products = readProducts();
  const novoProduto = { ...req.body, id: Date.now().toString() };
  products.push(novoProduto);
  saveProducts(products);
  res.json({ success: true });
});

app.put('/produtos/:id', (req, res) => {
  const products = readProducts();
  const index = products.findIndex(p => p.id === req.params.id);
  if (index === -1) return res.status(404).json({ success: false });
  products[index] = { ...products[index], ...req.body };
  saveProducts(products);
  res.json({ success: true });
});

app.delete('/produtos/:id', (req, res) => {
  let products = readProducts();
  products = products.filter(p => p.id !== req.params.id);
  saveProducts(products);
  res.json({ success: true });
});

// -------------------- Iniciar Servidor --------------------
app.listen(PORT, () => {
  console.log(`Servidor rodando em http://localhost:${PORT}`);
});

app.use(express.static(path.join(__dirname, '..'))); // serve tudo acima de /server
