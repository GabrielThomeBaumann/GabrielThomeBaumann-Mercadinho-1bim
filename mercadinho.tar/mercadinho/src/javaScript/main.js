// Cria gerente padrão se não existir
const gerentePadrao = {
    nome: "admin",
    email: "admin@site.com",
    idade: 30,
    senha: "admin123",
    genero: "masculino",
    tipo: "gerente"
};

let usuarios = JSON.parse(localStorage.getItem("usuarios")) || [];

if (!usuarios.find(u => u.email === gerentePadrao.email)) {
    usuarios.push(gerentePadrao);
    localStorage.setItem("usuarios", JSON.stringify(usuarios));
}
