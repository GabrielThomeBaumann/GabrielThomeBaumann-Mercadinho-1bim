function fazerLogin() {
    const nome = document.getElementById("userName").value.trim();
    const senha = document.getElementById("password").value;

    let usuarios = JSON.parse(localStorage.getItem("usuarios")) || [];

    const usuario = usuarios.find(u => u.nome === nome && u.senha === senha);

    if (!usuario) {
        alert("Usuário ou senha inválidos.");
        return;
    }

    // Armazena o usuário logado
    localStorage.setItem("usuarioLogado", JSON.stringify(usuario));

    alert(`Bem-vindo, ${usuario.nome}!`);

    // Redireciona conforme o tipo
    if (usuario.tipo === "gerente") {
        window.location.href = "admin.html";
    } else {
        window.location.href = "index.html"; // ou a página principal
    }
}
