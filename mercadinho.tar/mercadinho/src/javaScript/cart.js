document.addEventListener('DOMContentLoaded', () => {
  const tbody = document.getElementById('tabela-body');
  const totalDiv = document.getElementById('total');
  const comprarBtn = document.getElementById('comprar');
  const carrinho = JSON.parse(localStorage.getItem('carrinho')) || [];

  if (carrinho.length === 0) {
    document.getElementById('tabela').innerHTML = '<p>Seu carrinho está vazio.</p>';
    return;
  }

  let totalGeral = 0;

  carrinho.forEach((item, index) => {
    const row = document.createElement('tr');
    row.innerHTML = `
      <td>${item.name}</td>
      <td>${item.quantity}</td>
      <td>R$ ${item.unitPrice.toFixed(2)}</td>
      <td>R$ ${item.totalPrice.toFixed(2)}</td>
    `;

    const removeBtn = document.createElement('button');
    removeBtn.textContent = 'Remover';
    removeBtn.addEventListener('click', () => {
      carrinho.splice(index, 1);
      localStorage.setItem('carrinho', JSON.stringify(carrinho));
      location.reload();
    });

    const actionsCell = document.createElement('td');
    actionsCell.appendChild(removeBtn);
    row.appendChild(actionsCell);

    totalGeral += item.totalPrice;
    tbody.appendChild(row);
  });

  totalDiv.innerHTML = `<strong>Total geral:</strong> R$ ${totalGeral.toFixed(2)}`;

  comprarBtn.addEventListener('click', () => {
    alert('Compra realizada com sucesso! Obrigado pela preferência.');
    localStorage.removeItem('carrinho');
    location.reload();
  });
});


