document.addEventListener('DOMContentLoaded', () => {
  const produtosContainer = document.querySelector('.group1');

  // Excluir produto
  produtosContainer.addEventListener('click', (e) => {
    if (e.target.classList.contains('excluir')) {
      e.target.closest('.produto').remove();
    }

    // Editar produto
    if (e.target.classList.contains('editar')) {
      const produto = e.target.closest('.produto');
      const titulo = produto.querySelector('.produto-title').innerText;
      const descricao = produto.querySelector('.produto-description').innerText;
      const preco = produto.dataset.price;
      const imagem = produto.querySelector('img').src;

      const novoTitulo = prompt('Novo título:', titulo);
      const novaDescricao = prompt('Nova descrição:', descricao);
      const novoPreco = prompt('Novo preço:', preco);
      const novaImagem = prompt('URL da nova imagem:', imagem);

      if (novoTitulo) produto.querySelector('.produto-title').innerText = novoTitulo;
      if (novaDescricao) produto.querySelector('.produto-description').innerText = novaDescricao;
      if (novoPreco) {
        produto.dataset.price = parseFloat(novoPreco).toFixed(2);
        produto.querySelector('.produto-price').innerText = `R$ ${parseFloat(novoPreco).toFixed(2)}`;
      }
      if (novaImagem) produto.querySelector('img').src = novaImagem;
    }
  });

  // Adicionar novo produto
  document.getElementById('adicionarProduto').addEventListener('click', () => {
    const titulo = prompt('Título do produto:');
    const descricao = prompt('Descrição do produto:');
    const preco = prompt('Preço do produto:');
    const imagem = prompt('URL da imagem do produto:');

    if (!titulo || !descricao || !preco || !imagem) {
      alert('Todos os campos são obrigatórios.');
      return;
    }

    const novoProduto = document.createElement('li');
    novoProduto.className = 'produto';
    novoProduto.dataset.price = parseFloat(preco).toFixed(2);
    novoProduto.innerHTML = `
      <img src="${imagem}" alt="${titulo}">
      <div class="produto-info">
        <div class="produto-title">${titulo}</div>
        <div class="produto-description">${descricao}</div>
        <div class="produto-price">R$ ${parseFloat(preco).toFixed(2)}</div>
      </div>
      <div class="produto-actions">
        <button class="excluir">Excluir</button>
        <button class="editar">Editar</button>
      </div>
    `;

    produtosContainer.appendChild(novoProduto);
  });
});
