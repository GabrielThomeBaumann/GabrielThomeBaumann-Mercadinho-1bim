document.addEventListener('DOMContentLoaded', () => {
  const produtosContainer = document.querySelector('.group1');

  // Excluir ou Editar Produto
  produtosContainer.addEventListener('click', (e) => {
    if (e.target.classList.contains('excluir')) {
      e.target.closest('.produto').remove();
    }

    if (e.target.classList.contains('editar')) {
      const produto = e.target.closest('.produto');
      const tituloEl = produto.querySelector('.produto-title');
      const descricaoEl = produto.querySelector('.produto-description');
      const precoEl = produto.querySelector('.produto-price');
      const imagemEl = produto.querySelector('img');
      const descontoEl = produto.querySelector('.discount');

      const precoAtual = parseFloat(produto.dataset.price);
      const descontoAtual = descontoEl ? descontoEl.innerText.replace('%', '') : '';

      const novoTitulo = prompt('Novo título:', tituloEl.innerText);
      const novaDescricao = prompt('Nova descrição:', descricaoEl.innerText);
      const novoPrecoStr = prompt('Novo preço:', precoAtual);
      const novaImagem = prompt('Nova URL da imagem:', imagemEl.src);
      const novoDesconto = prompt('Novo desconto (%) [opcional]:', descontoAtual);

      const novoPreco = parseFloat(novoPrecoStr);
      const descontoNum = parseInt(novoDesconto);

      if (novoPrecoStr && (isNaN(novoPreco) || novoPreco < 0)) {
        alert('Preço inválido.');
        return;
      }

      if (novoDesconto && (isNaN(descontoNum) || descontoNum < 0 || descontoNum > 100)) {
        alert('Desconto inválido. Deve ser entre 0% e 100%.');
        return;
      }

      if (novoTitulo) tituloEl.innerText = novoTitulo;
      if (novaDescricao) descricaoEl.innerText = novaDescricao;
      if (novoPrecoStr) {
        produto.dataset.price = novoPreco.toFixed(2);
        precoEl.innerText = novoPreco.toLocaleString('pt-BR', {
          style: 'currency',
          currency: 'BRL'
        });
      }
      if (novaImagem) imagemEl.src = novaImagem;

      // Desconto
      if (novoDesconto === '') {
        if (descontoEl) descontoEl.remove();
      } else if (!descontoEl) {
        const div = document.createElement('div');
        div.classList.add('discount');
        div.innerText = `${descontoNum}%`;
        produto.insertBefore(div, produto.querySelector('.produto-info'));
      } else {
        descontoEl.innerText = `${descontoNum}%`;
      }
    }
  });

  // Adicionar novo produto
  document.getElementById('adicionarProduto').addEventListener('click', () => {
    const titulo = prompt('Título do produto:');
    const descricao = prompt('Descrição do produto:');
    const precoStr = prompt('Preço do produto:');
    const imagem = prompt('URL da imagem do produto:');
    const descontoStr = prompt('Desconto (%) [opcional]:');

    const preco = parseFloat(precoStr);
    const desconto = descontoStr ? parseInt(descontoStr) : null;

    if (!titulo || !descricao || !precoStr || !imagem) {
      alert('Todos os campos são obrigatórios (exceto desconto).');
      return;
    }

    if (isNaN(preco) || preco < 0) {
      alert('Preço inválido.');
      return;
    }

    if (descontoStr && (isNaN(desconto) || desconto < 0 || desconto > 100)) {
      alert('Desconto inválido. Deve ser entre 0 e 100.');
      return;
    }

    const novoProduto = document.createElement('li');
    novoProduto.className = 'produto';
    novoProduto.dataset.price = preco.toFixed(2);

    const precoFormatado = preco.toLocaleString('pt-BR', {
      style: 'currency',
      currency: 'BRL'
    });

    novoProduto.innerHTML = `
      <img src="${imagem}" alt="${titulo}">
      ${desconto !== null ? `<div class="discount">${desconto}%</div>` : ''}
      <div class="produto-info">
        <div class="produto-title">${titulo}</div>
        <div class="produto-description">${descricao}</div>
        <div class="produto-price">${precoFormatado}</div>
      </div>
      <div class="produto-actions">
        <button class="excluir">Excluir</button>
        <button class="editar">Editar</button>
      </div>
    `;

    produtosContainer.appendChild(novoProduto);
  });
});

