document.addEventListener('DOMContentLoaded', () => {
  let usuarios = [
    {
      nome: 'João Silva',
      email: 'joao@gmail.com',
      idade: 25,
      genero: 'Masculino',
      tipo: 'cliente'
    },
    {
      nome: 'Maria Oliveira',
      email: 'maria@gmail.com',
      idade: 30,
      genero: 'Feminino',
      tipo: 'gerente'
    }
  ];

  const tbody = document.getElementById('usuarios-body');

  function renderUsuarios() {
    tbody.innerHTML = '';
    usuarios.forEach((usuario, index) => {
      const tr = document.createElement('tr');
      tr.innerHTML = `
        <td>${usuario.nome}</td>
        <td>${usuario.email}</td>
        <td>${usuario.idade}</td>
        <td>${usuario.genero}</td>
        <td>${usuario.tipo.charAt(0).toUpperCase() + usuario.tipo.slice(1)}</td>
        <td>
          <button onclick="promoverUsuario(${index})">
            ${usuario.tipo === 'cliente' ? 'Promover a Gerente' : 'Rebaixar a Cliente'}
          </button>
          <button onclick="editarUsuario(${index})">Editar</button>
          <button onclick="removerUsuario(${index})" style="background-color:red;">Remover</button>
        </td>
      `;
      tbody.appendChild(tr);
    });
  }

  window.promoverUsuario = (index) => {
    usuarios[index].tipo = usuarios[index].tipo === 'cliente' ? 'gerente' : 'cliente';
    renderUsuarios();
  };

  window.removerUsuario = (index) => {
    if (confirm(`Tem certeza que deseja remover ${usuarios[index].nome}?`)) {
      usuarios.splice(index, 1);
      renderUsuarios();
    }
  };

  window.editarUsuario = (index) => {
    const usuario = usuarios[index];
    const novoNome = prompt('Novo nome:', usuario.nome);
    const novoEmail = prompt('Novo e-mail:', usuario.email);
    const novaIdade = prompt('Nova idade:', usuario.idade);
    const novoGenero = prompt('Novo gênero (Masculino/Feminino):', usuario.genero);

    if (novoNome && novoEmail && novaIdade && novoGenero) {
      usuarios[index] = {
        ...usuario,
        nome: novoNome,
        email: novoEmail,
        idade: parseInt(novaIdade),
        genero: novoGenero
      };
      renderUsuarios();
    }
  };

  document.getElementById('atualizar').addEventListener('click', renderUsuarios);
  renderUsuarios();
});

