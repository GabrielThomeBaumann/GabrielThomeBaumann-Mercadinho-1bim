function cadastrarUsuario() {
    const nome = document.getElementById("userName").value.trim();
    const email = document.getElementById("gmail").value.trim();
    const idade = document.getElementById("age").value;
    const senha = document.getElementById("password").value;
    const genero = document.getElementById("gender").value;

    if (!nome || !email || !idade || !senha || !genero) {
        alert("Preencha todos os campos.");
        return;
    }

    let usuarios = JSON.parse(localStorage.getItem("usuarios")) || [];

    // Verifica se o email já está cadastrado
    if (usuarios.find(u => u.email === email)) {
        alert("Email já cadastrado.");
        return;
    }

    const novoUsuario = {
        nome,
        email,
        idade: Number(idade),
        senha,
        genero,
        tipo: "cliente" // padrão
    };

    usuarios.push(novoUsuario);
    localStorage.setItem("usuarios", JSON.stringify(usuarios));

    alert("Usuário cadastrado com sucesso!");
    window.location.href = "login.html";
}
