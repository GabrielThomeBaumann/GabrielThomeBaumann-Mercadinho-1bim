const produtos = document.querySelectorAll('.produto');

produtos.forEach(produto => {
  const increaseBtn = produto.querySelector('.increase');
  const decreaseBtn = produto.querySelector('.decrease');
  const quantitySpan = produto.querySelector('.quantity');
  const addToCartBtn = produto.querySelector('.add-to-cart');

  let quantity = 0;
  const price = parseFloat(produto.dataset.price);
  const id = produto.dataset.id;
  const name = produto.querySelector('.produto-title').textContent;

  increaseBtn.addEventListener('click', () => {
    quantity++;
    quantitySpan.textContent = quantity;
  });

  decreaseBtn.addEventListener('click', () => {
    if (quantity > 0) {
      quantity--;
      quantitySpan.textContent = quantity;
    }
  });

  addToCartBtn.addEventListener('click', () => {
    if (quantity === 0) return;

    const totalPrice = (quantity * price).toFixed(2);

    const item = {
      id,
      name,
      quantity,
      unitPrice: price,
      totalPrice: parseFloat(totalPrice)
    };

    const carrinho = JSON.parse(localStorage.getItem('carrinho')) || [];

    const existing = carrinho.find(p => p.id === id);
    if (existing) {
      existing.quantity += item.quantity;
      existing.totalPrice = parseFloat((existing.quantity * existing.unitPrice).toFixed(2));
    } else {
      carrinho.push(item);
    }

    localStorage.setItem('carrinho', JSON.stringify(carrinho));

    quantity = 0;
    quantitySpan.textContent = quantity;

    console.log(`Adicionado ao carrinho: ${name} x${item.quantity} - R$ ${item.totalPrice}`);
  });
});
